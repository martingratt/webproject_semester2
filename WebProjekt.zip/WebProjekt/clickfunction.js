
$(function () {
    $("#a").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("a");

    });

});

$(function () {
    $("#b").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("b");

    });

});

$(function () {
    $("#c").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("c");

    });

});

$ (function () {
    $("#d").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("d");

    });

});

$ (function () {
    $("#e").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("e");

    });

});

$ (function () {
    $("#f").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("f");

    });

});

$ (function () {
    $("#g").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("g");

    });

});

$ (function () {
    $("#h").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("h");

    });

});

$ (function () {
    $("#i").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("i");

    });

});

$ (function () {
    $("#j").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("j");

    });

});

$ (function () {
    $("#k").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("k");

    });

});

$ (function () {
    $("#l").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("l");

    });

});

$ (function () {
    $("#m").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("m");

    });

});

$ (function () {
    $("#n").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("n");

    });

});

$ (function () {
    $("#o").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("o");

    });

});

$ (function () {
    $("#p").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("p");

    });

});

$ (function () {
    $("#q").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("q");

    });

});

$ (function () {
    $("#r").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("r");

    });

});

$ (function () {
    $("#s").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("s");

    });

});

$ (function () {
    $("#t").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("t");

    });

});

$ (function () {
    $("#u").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("u");

    });

});

$ (function () {
    $("#v").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("v");

    });

});

$ (function () {
    $("#w").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("w");

    });

});

$ (function () {
    $("#x").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("x");

    });

});

$ (function () {
    $("#y").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("y");

    });

});

$(function () {
    $("#z").click(function (event) {
        event.preventDefault();
        Main.UpdateLetter("z");

    });

});