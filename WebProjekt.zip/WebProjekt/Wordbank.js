/**
 * Created by Admin on 15.06.2017.
 */
Words = {};
Words.List =[];

Words.List[0] = "";
Words.List[1] = "";
Words.List[2] = "";
Words.List[3] = "";
Words.List[4] = "";
Words.List[5] = "";
Words.List[6] = "";
Words.List[7] = "";
Words.List[8] = "";
Words.List[9] = "";

Words.List[0] = "juventus";
Words.List[1] = "milan";
Words.List[2] = "inter";
Words.List[3] = "roma";
Words.List[4] = "napoli";
Words.List[5] = "chelsea";
Words.List[6] = "manchesterunited";
Words.List[7] = "tottenham";
Words.List[8] = "arsenal";
Words.List[9] = "manchestercity";

Words.List[10] = "barcelona";
Words.List[11] = "realmadrid";
Words.List[12] = "atleti";
Words.List[13] = "villareal";
Words.List[14] = "valencia";
Words.List[15] = "bayern";
Words.List[16] = "dortmund";
Words.List[17] = "schalke";
Words.List[18] = "leverkusen";
Words.List[19] = "paris";


Words.Length = Words.List.length;
